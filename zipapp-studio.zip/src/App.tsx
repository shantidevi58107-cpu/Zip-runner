/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useCallback, useEffect, useRef, useMemo } from 'react';
import JSZip from 'jszip';
import { useDropzone } from 'react-dropzone';
import { 
  File as FileIcon, 
  Folder, 
  ChevronRight, 
  ChevronDown, 
  Upload, 
  Play, 
  X, 
  Download, 
  Eye, 
  Code,
  Globe,
  Settings,
  Plus,
  Trash2,
  FileArchive,
  ShieldCheck,
  ShieldAlert,
  Smartphone,
  Info,
  CheckCircle2,
  AlertTriangle,
  Zap,
  Activity,
  Maximize2,
  Minimize2,
  RotateCcw,
  RefreshCw,
  FileText,
  FileCode,
  FileImage,
  FileVideo,
  FileAudio,
  FileSearch,
  Type,
  Sparkles,
  Bot,
  BrainCircuit,
  Wand2
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import Prism from 'prismjs';
import Markdown from 'react-markdown';
import { GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || '' });

// Import Prism languages
import 'prismjs/components/prism-javascript';
import 'prismjs/components/prism-typescript';
import 'prismjs/components/prism-css';
import 'prismjs/components/prism-markup'; // HTML
import 'prismjs/components/prism-json';

type FileEntry = {
  name: string;
  path: string;
  isDir: boolean;
  content?: string | ArrayBuffer;
  zipObject: JSZip.JSZipObject | null;
};

type TreeNode = {
  name: string;
  path: string;
  children: { [key: string]: TreeNode };
  isDir: boolean;
  entry: FileEntry | null;
};

type SafetyIssue = {
  type: 'warning' | 'error' | 'info';
  message: string;
  file: string;
  line?: number;
};

type MainViewMode = 'explorer' | 'security' | 'convert';

export default function App() {
  const [zip, setZip] = useState<JSZip | null>(null);
  const [tree, setTree] = useState<TreeNode | null>(null);
  const [selectedPath, setSelectedPath] = useState<string | null>(null);
  const [fileContent, setFileContent] = useState<string | null>(null);
  const [previewMode, setPreviewMode] = useState<'view' | 'run'>('view');
  const [mainView, setMainView] = useState<MainViewMode>('explorer');
  const [runnerUrl, setRunnerUrl] = useState<string | null>(null);
  const [zipName, setZipName] = useState<string>('untitled.zip');
  const [isLoading, setIsLoading] = useState(false);
  const [aiAnalysis, setAiAnalysis] = useState<{ projectType: string, suggestions: string[] } | null>(null);
  const [isAiRefactoring, setIsAiRefactoring] = useState(false);

  // Security Scan Results
  const [safetyIssues, setSafetyIssues] = useState<SafetyIssue[]>([]);
  const [isScanning, setIsScanning] = useState(false);

  // PWA Manifest State
  const [pwaConfig, setPwaConfig] = useState({
    name: 'My Web App',
    shortName: 'App',
    themeColor: '#141414',
    backgroundColor: '#E4E3E0',
    display: 'standalone'
  });

  const onDrop = useCallback(async (acceptedFiles: File[]) => {
    const file = acceptedFiles[0];
    if (!file) return;

    setZipName(file.name);
    setIsLoading(true);
    setMainView('explorer');
    setAiAnalysis(null);
    try {
      const reader = new FileReader();
      reader.onload = async (e) => {
        const data = e.target?.result;
        if (data && data instanceof ArrayBuffer) {
          const loadedZip = await JSZip.loadAsync(data);
          setZip(loadedZip);
          buildTree(loadedZip);
          // Auto scan on load
          performSafetyScan(loadedZip);
        }
        setIsLoading(false);
      };
      reader.readAsArrayBuffer(file);
    } catch (err) {
      console.error("Failed to load ZIP:", err);
      setIsLoading(false);
    }
  }, []);

  const smartAnalyze = async () => {
    if (!zip) return;
    setIsLoading(true);
    try {
      const fileNames = Object.keys(zip.files).slice(0, 50); // Send first 50 files for context
      const prompt = `Analyze this list of files from a ZIP archive and identify:
1. The likely "Project Type" (e.g., Static HTML, React, Node.js, Python, etc.)
2. 3 short technical conversion suggestions (e.g., "Convert JS to Web Components", "Modernize CSS").

Files:
${fileNames.join('\n')}

Return ONLY JSON in this format: {"projectType": "...", "suggestions": ["...", "...", "..."]}`;

      const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: prompt,
      });

      const text = response.text || '{}';
      const cleaned = text.replace(/```json|```/g, '').trim();
      const result = JSON.parse(cleaned);
      setAiAnalysis(result);
    } catch (err) {
      console.error("AI Analysis failed:", err);
    } finally {
      setIsLoading(false);
    }
  };

  const aiRefactorFile = async (targetFormat: string) => {
    if (!selectedPath || !fileContent || !zip) return;
    setIsAiRefactoring(true);
    try {
      const prompt = `Convert or Refactor the following source code into "${targetFormat}" format. 
Return ONLY the converted code content, no markdown blocks, no explanations.

Path: ${selectedPath}
Content:
${fileContent}`;

      const response = await ai.models.generateContent({
        model: "gemini-3.1-pro-preview",
        contents: prompt,
      });

      const convertedContent = response.text || '';
      
      // Update ZIP in memory
      const newZip = await JSZip.loadAsync(await zip.generateAsync({ type: 'blob' }));
      newZip.file(selectedPath, convertedContent);
      setZip(newZip);
      buildTree(newZip);
      setFileContent(convertedContent);
      alert(`${selectedPath} has been refactored to ${targetFormat} via AI.`);
    } catch (err) {
      console.error("AI Refactor failed:", err);
      alert("AI Conversion failed. Check console.");
    } finally {
      setIsAiRefactoring(false);
    }
  };

  //@ts-ignore
  const { getRootProps, getInputProps, isDragActive } = useDropzone({ 
    onDrop, 
    accept: { 'application/zip': ['.zip'] },
    noClick: !!zip,
    multiple: false
  });

  const buildTree = (zipObj: JSZip) => {
    const root: TreeNode = { name: 'root', path: '', children: {}, isDir: true, entry: null };
    zipObj.forEach((relativePath, file) => {
      const parts = relativePath.split('/').filter(p => p);
      let current = root;
      parts.forEach((part, index) => {
        const isDir = file.dir || index < parts.length - 1;
        const path = parts.slice(0, index + 1).join('/');
        if (!current.children[part]) {
          current.children[part] = {
            name: part,
            path: path,
            children: {},
            isDir: isDir,
            entry: index === parts.length - 1 && !file.dir ? {
              name: part,
              path: path,
              isDir: false,
              zipObject: file
            } : null
          };
        }
        current = current.children[part];
      });
    });
    setTree(root);
  };

  const performSafetyScan = async (zipObj: JSZip) => {
    setIsScanning(true);
    const issues: SafetyIssue[] = [];
    
    // Look for entry point
    const fileNames = Object.keys(zipObj.files);
    const hasIndex = fileNames.some(n => n.toLowerCase().endsWith('index.html'));
    if (!hasIndex) {
      issues.push({ type: 'error', message: 'No index.html found. Play Store apps require a valid entry point.', file: 'Project Root' });
    }

    for (const name of fileNames) {
      const file = zipObj.files[name];
      if (file.dir) continue;

      const ext = name.split('.').pop()?.toLowerCase();
      if (['js', 'html', 'ts', 'tsx', 'jsx'].includes(ext || '')) {
        const text = await file.async('string');
        
        // Scan for dangerous patterns
        if (text.includes('eval(')) {
          issues.push({ type: 'warning', message: 'Use of eval() detected. This is a common security risk.', file: name });
        }
        if (text.includes('src="http:')) {
          issues.push({ type: 'warning', message: 'Insecure script/asset loading (HTTP). Use HTTPS only for App Stores.', file: name });
        }
        if (text.includes('atob(') || text.includes('String.fromCharCode(')) {
          issues.push({ type: 'info', message: 'Obfuscation patterns detected. Verify this logic manually.', file: name });
        }
        if (text.includes('<iframe')) {
          issues.push({ type: 'info', message: 'Iframe detected. Ensure framed content is from trusted origins.', file: name });
        }
      }
    }
    
    setSafetyIssues(issues);
    setIsScanning(false);
  };

  const handleFileSelect = async (path: string, entry: FileEntry) => {
    if (entry.isDir) return;
    setSelectedPath(path);
    setPreviewMode('view');
    setMainView('explorer');
    
    if (entry.zipObject) {
      const extension = path.split('.').pop()?.toLowerCase();
      const binaryTypes = ['png', 'jpg', 'jpeg', 'gif', 'svg', 'webp', 'mp4', 'webm', 'ogg', 'mp3', 'wav', 'pdf'];
      
      if (binaryTypes.includes(extension || '')) {
        const blob = await entry.zipObject.async('blob');
        const url = URL.createObjectURL(blob);
        setFileContent(url);
      } else {
        const text = await entry.zipObject.async('string');
        setFileContent(text);
      }
    }
  };

  const runProject = async () => {
    if (!zip) return;
    setIsLoading(true);
    setPreviewMode('run');
    try {
      const blobUrls: { [path: string]: string } = {};
      const fileNames = Object.keys(zip.files);
      
      // Virtualize all assets
      for (const name of fileNames) {
        const file = zip.files[name];
        if (!file.dir) {
          const blob = await file.async('blob');
          const ext = name.split('.').pop()?.toLowerCase();
          const mimeMaps: { [key: string]: string } = {
            'js': 'application/javascript',
            'css': 'text/css',
            'html': 'text/html',
            'json': 'application/json',
            'png': 'image/png',
            'jpg': 'image/jpeg',
            'jpeg': 'image/jpeg',
            'gif': 'image/gif',
            'svg': 'image/svg+xml',
            'webp': 'image/webp'
          };
          const finalBlob = mimeMaps[ext || ''] ? new Blob([blob], { type: mimeMaps[ext || ''] }) : blob;
          blobUrls[name] = URL.createObjectURL(finalBlob);
        }
      }
      
      // Intelligent entry point detection
      const entryPoints = [
        'index.html',
        'main.html',
        'app.html',
        'home.html',
        'default.html'
      ];
      
      let entryPoint = fileNames.find(n => entryPoints.includes(n.toLowerCase().split('/').pop() || ''));
      if (!entryPoint) {
        entryPoint = fileNames.find(n => n.toLowerCase().endsWith('.html'));
      }

      if (!entryPoint) {
        alert("No HTML entry point found! Please ensure your ZIP contains an index.html or similar.");
        setPreviewMode('view');
        setIsLoading(false);
        return;
      }

      const htmlContent = await zip.files[entryPoint].async('string');
      let rewrittenHtml = htmlContent;
      
      // Sort keys by length descending to prevent partial path match issues (e.g., "styles.css" matching before "assets/styles.css")
      const sortedPaths = Object.keys(blobUrls).sort((a, b) => b.length - a.length);
      
      sortedPaths.forEach(originalPath => {
        const url = blobUrls[originalPath];
        // Replace relative paths in HTML/CSS
        // This is a naive regex-based rewriter, but covers 90% of simple static sites
        const escapedPath = originalPath.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
        const regex = new RegExp(`(src|href|content)=["'](\\./)?${escapedPath}["']`, 'g');
        rewrittenHtml = rewrittenHtml.replace(regex, `$1="${url}"`);
      });

      const finalBlob = new Blob([rewrittenHtml], { type: 'text/html' });
      const finalUrl = URL.createObjectURL(finalBlob);
      setRunnerUrl(finalUrl);
    } catch (err) {
      console.error("Runner execution failed:", err);
      alert("Execution error check console.");
    } finally {
      setIsLoading(false);
    }
  };

  const closeRunner = () => {
    setPreviewMode('view');
    if (runnerUrl) URL.revokeObjectURL(runnerUrl);
    setRunnerUrl(null);
  };

  const generateAppZip = async () => {
    if (!zip) return;
    setIsLoading(true);
    try {
      const manifest = {
        name: pwaConfig.name,
        short_name: pwaConfig.shortName,
        start_url: '.',
        display: pwaConfig.display,
        background_color: pwaConfig.backgroundColor,
        theme_color: pwaConfig.themeColor,
        icons: []
      };

      const newZip = await JSZip.loadAsync(await zip.generateAsync({ type: 'blob' }));
      newZip.file('manifest.json', JSON.stringify(manifest, null, 2));
      
      const content = await newZip.generateAsync({ type: 'blob' });
      const url = URL.createObjectURL(content);
      const a = document.createElement('a');
      a.href = url;
      a.download = `app_${pwaConfig.shortName.toLowerCase()}.zip`;
      a.click();
    } catch (err) {
      console.error("Export error:", err);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="flex flex-col h-screen bg-[#050505] text-[#E4E3E0] font-sans overflow-hidden hardware-grid">
      {/* Header */}
      <header className="flex items-center justify-between px-8 py-5 border-b border-white/5 bg-[#0D0D0D]/80 backdrop-blur-xl z-20 sticky top-0">
        <div className="flex items-center gap-6">
          <div className="relative group cursor-pointer" onClick={() => setZip(null)}>
            <motion.div 
              whileHover={{ rotate: -5, scale: 1.05, boxShadow: "0 0 30px rgba(99, 102, 241, 0.4)" }}
              whileTap={{ scale: 0.95 }}
              className="w-14 h-14 bg-white flex items-center justify-center rounded-2xl shadow-2xl border-2 border-white/10"
            >
              <FileArchive className="text-[#050505] w-8 h-8" />
            </motion.div>
            {zip && (
              <motion.div 
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                className="absolute -top-1 -right-1 w-5 h-5 bg-indigo-500 rounded-full border-4 border-[#0D0D0D] shadow-[0_0_15px_rgba(99,102,241,0.5)]" 
              />
            )}
          </div>
          <div>
            <div className="flex items-baseline gap-2">
              <h1 className="text-xl font-black uppercase tracking-tighter leading-none text-white">ZipApp Studio</h1>
              <span className="text-[10px] font-black opacity-40 uppercase tracking-[0.2em] text-indigo-400">Build 3.0.1</span>
            </div>
            <div className="flex items-center gap-2 mt-2">
              <div className="flex gap-0.5">
                {[...Array(3)].map((_, i) => (
                  <motion.div 
                    animate={{ opacity: [0.2, 1, 0.2] }}
                    transition={{ duration: 2, repeat: Infinity, delay: i * 0.3 }}
                    key={i} 
                    className="w-1 h-3 bg-indigo-500 rounded-full" 
                  />
                ))}
              </div>
              <p className="text-[10px] font-mono opacity-40 uppercase tracking-widest truncate max-w-[200px]">{zipName}</p>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-8">
          {zip && (
            <div className="hidden md:flex items-center gap-10 mr-10 border-r border-white/5 pr-10">
              <div className="flex flex-col items-end">
                <span className="text-[9px] font-black uppercase tracking-widest opacity-20">Compression</span>
                <span className="text-xs font-mono font-bold text-white italic">LZMA-PRO</span>
              </div>
              <div className="flex flex-col items-end border-l border-white/5 pl-10">
                <span className="text-[9px] font-black uppercase tracking-widest opacity-20">Sanity</span>
                <span className="text-xs font-mono font-bold text-cyan-400 uppercase tracking-tighter">SECURED ENDGATE</span>
              </div>
            </div>
          )}

          <div className="flex items-center bg-white/5 p-1.5 rounded-[24px] border border-white/10 shadow-inner">
            <button 
              onClick={() => setMainView('explorer')}
              className={`px-6 py-2.5 text-[11px] font-black uppercase tracking-widest rounded-2xl transition-all flex items-center gap-2 ${
                mainView === 'explorer' ? 'bg-white text-[#050505] shadow-[0_0_20px_rgba(255,255,255,0.2)]' : 'text-white opacity-30 hover:opacity-100'
              }`}
            >
              <Folder size={14} />
              Explorer
            </button>
            <button 
              onClick={() => setMainView('security')}
              className={`px-6 py-2.5 text-[11px] font-black uppercase tracking-widest rounded-2xl transition-all flex items-center gap-2 ${
                mainView === 'security' ? 'bg-white text-[#050505] shadow-[0_0_20px_rgba(255,255,255,0.2)]' : 'text-white opacity-30 hover:opacity-100'
              }`}
            >
              <ShieldCheck size={14} />
              Audit
            </button>
            <button 
              onClick={() => setMainView('convert')}
              className={`px-6 py-2.5 text-[11px] font-black uppercase tracking-widest rounded-2xl transition-all flex items-center gap-2 ${
                mainView === 'convert' ? 'bg-white text-[#050505] shadow-[0_0_20px_rgba(255,255,255,0.2)]' : 'text-white opacity-30 hover:opacity-100'
              }`}
            >
              <Sparkles size={14} />
              Forge
            </button>
          </div>
        </div>
      </header>

      <main className="flex flex-1 overflow-hidden relative bg-[#050505]">
        {!zip ? (
          <div 
            {...getRootProps()} 
            className={`flex-1 flex flex-col items-center justify-center p-32 transition-all duration-500 relative ${isDragActive ? 'bg-indigo-500/5' : ''}`}
          >
            <div className="absolute inset-0 hardware-grid opacity-20 pointer-events-none" />
            <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-indigo-600/10 blur-[150px] rounded-full pointer-events-none animate-pulse" />
            <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-cyan-600/10 blur-[150px] rounded-full pointer-events-none animate-pulse" />
            
            <input {...getInputProps()} />
            <motion.div 
              initial={{ y: 60, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
              className="text-center max-w-4xl w-full relative z-10"
            >
              <div className="relative mb-16 inline-block">
                <motion.div 
                  animate={{ 
                    rotate: isDragActive ? 180 : 0,
                    scale: isDragActive ? 1.1 : 1,
                    boxShadow: isDragActive ? "0 0 60px rgba(99, 102, 241, 0.3)" : "0 0 20px rgba(255, 255, 255, 0.1)"
                  }}
                  className="w-40 h-40 bg-[#0D0D0D] rounded-[52px] flex items-center justify-center text-white border border-white/10 relative z-10 group cursor-pointer"
                >
                  <Upload size={64} className="opacity-20 group-hover:opacity-100 transition-all group-hover:scale-110" />
                  <motion.div 
                    animate={{ y: [0, -10, 0], opacity: [0.2, 0.6, 0.2] }}
                    transition={{ duration: 3, repeat: Infinity }}
                    className="absolute inset-0 flex items-center justify-center pointer-events-none"
                  >
                    <Plus size={32} className="text-indigo-400 opacity-40" />
                  </motion.div>
                </motion.div>
              </div>

              <h2 className="text-[10vw] md:text-8xl font-black tracking-[-0.04em] mb-8 text-white leading-[0.85] uppercase selection:bg-white selection:text-black">
                Neural Archive<br />
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-indigo-400 to-cyan-400">Interceptor</span>
              </h2>

              <p className="text-white opacity-30 font-black text-sm leading-relaxed uppercase tracking-[0.4em] mb-16 max-w-xl mx-auto italic">
                Hardware-accelerated binary processing.<br />
                Real-time security auditing and neural refactoring.
              </p>

              <div className="flex flex-wrap justify-center gap-10">
                <div className="flex flex-col items-center gap-4">
                  <div className="w-12 h-12 bg-white/5 rounded-2xl flex items-center justify-center border border-white/5 shadow-[0_0_20px_rgba(255,255,255,0.02)]">
                    <ShieldCheck size={20} className="text-green-400 opacity-60" />
                  </div>
                  <span className="text-[9px] font-black uppercase tracking-[0.2em] opacity-40">Zero-Point Audit</span>
                </div>
                <div className="flex flex-col items-center gap-4">
                  <div className="w-12 h-12 bg-white/5 rounded-2xl flex items-center justify-center border border-white/5 shadow-[0_0_20px_rgba(255,255,255,0.02)]">
                    <BrainCircuit size={20} className="text-indigo-400 opacity-60" />
                  </div>
                  <span className="text-[9px] font-black uppercase tracking-[0.2em] opacity-40">Gemini Core</span>
                </div>
                <div className="flex flex-col items-center gap-4">
                  <div className="w-12 h-12 bg-white/5 rounded-2xl flex items-center justify-center border border-white/5 shadow-[0_0_20px_rgba(255,255,255,0.02)]">
                    <Play size={20} className="text-cyan-400 opacity-60" />
                  </div>
                  <span className="text-[9px] font-black uppercase tracking-[0.2em] opacity-40">Live Virtualizer</span>
                </div>
              </div>
            </motion.div>
          </div>
        ) : (
          <>
            {/* Sidebar / Tree */}
            <AnimatePresence>
              {mainView === 'explorer' && (
                <motion.div 
                  initial={{ x: -20, opacity: 0 }}
                  animate={{ x: 0, opacity: 1 }}
                  exit={{ x: -20, opacity: 0 }}
                  className="w-80 border-r border-white/5 bg-[#0D0D0D] flex flex-col z-10 shadow-[20px_0_50px_rgba(0,0,0,0.5)]"
                >
                  <div className="px-8 py-6 border-b border-white/5 flex items-center justify-between">
                    <span className="text-[10px] font-black uppercase tracking-[0.3em] text-white opacity-30 italic">Sources_Matrix</span>
                    <Globe size={14} className="opacity-20 text-indigo-400" />
                  </div>
                  <div className="flex-1 overflow-y-auto p-4 custom-scrollbar">
                    {tree && <TreeComponent node={tree} onSelect={handleFileSelect} selectedPath={selectedPath} level={0} />}
                  </div>
                  
                  <div className="p-8 border-t border-white/5 bg-[#0D0D0D]">
                    <motion.button 
                      whileHover={{ scale: 1.02, y: -2, boxShadow: "0 10px 40px rgba(99, 102, 241, 0.4)" }}
                      whileTap={{ scale: 0.98 }}
                      onClick={runProject}
                      className="w-full flex items-center justify-center gap-4 py-5 bg-indigo-600 text-white text-[11px] font-black uppercase tracking-[0.3em] rounded-2xl shadow-2xl transition-all border-t border-white/20"
                    >
                      <Play size={16} fill="currentColor" />
                      <span>Start Sandbox</span>
                    </motion.button>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>

            {/* Content Area */}
            <div className="flex-1 bg-[#050505] relative overflow-hidden flex flex-col">
              <AnimatePresence mode="wait">
                {previewMode === 'run' ? (
                  <motion.div 
                    key="runner"
                    initial={{ opacity: 0, scale: 0.98, y: 10 }}
                    animate={{ opacity: 1, scale: 1, y: 0 }}
                    exit={{ opacity: 0, scale: 1.05 }}
                    className="w-full h-full flex flex-col p-6 md:p-10"
                  >
                    <div className="bg-[#141414] text-white px-8 py-4 flex items-center justify-between z-10 rounded-t-[32px] shadow-2xl border-x border-t border-white/10">
                      <div className="flex items-center gap-6">
                        <div className="flex items-center gap-2">
                          <div className="w-2 h-2 rounded-full bg-cyan-400 animate-ping" />
                          <div className="w-2 h-2 rounded-full bg-cyan-400 shadow-[0_0_10px_rgba(34,211,238,0.8)]" />
                        </div>
                        <div className="h-4 w-px bg-white/10 ml-2" />
                        <span className="text-[10px] font-black uppercase tracking-[0.3em] opacity-60">High-Fidelity Virtual Instance</span>
                      </div>
                      <div className="flex items-center gap-4">
                        <button onClick={closeRunner} className="hover:text-red-400 transition-all flex items-center gap-3 text-[10px] font-black uppercase tracking-[0.2em] pl-6 border-l border-white/10 group">
                          <span>Terminate Instance</span>
                          <X size={20} className="group-hover:rotate-90 transition-transform" />
                        </button>
                      </div>
                    </div>
                    <div className="flex-1 w-full bg-[#0D0D0D] relative rounded-b-[32px] overflow-hidden shadow-[0_0_100px_rgba(0,0,0,0.5)] border-x border-b border-white/5">
                      {isLoading ? (
                        <div className="absolute inset-0 flex flex-col items-center justify-center bg-[#0D0D0D] z-20">
                          <div className="w-24 h-24 relative mb-8">
                            <motion.div 
                              animate={{ rotate: 360 }}
                              transition={{ duration: 3, repeat: Infinity, ease: "linear" }}
                              className="absolute inset-0 border-4 border-white/5 rounded-full" 
                            />
                            <motion.div 
                              animate={{ rotate: -360 }}
                              transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
                              className="absolute inset-4 border-2 border-t-indigo-500 border-l-indigo-500/20 border-r-transparent border-b-transparent rounded-full" 
                            />
                          </div>
                          <span className="text-[11px] font-black uppercase tracking-[0.5em] text-white/40 animate-pulse">Neural Rehydration in Progress</span>
                        </div>
                      ) : (
                        <iframe 
                          src={runnerUrl || ''} 
                          className="w-full h-full border-none bg-[#0D0D0D]"
                          title="App Runner"
                        />
                      )}
                    </div>
                  </motion.div>
                ) : mainView === 'security' ? (
                  <SecurityPanel issues={safetyIssues} isScanning={isScanning} onRescan={() => zip && performSafetyScan(zip)} />
                ) : mainView === 'convert' ? (
                  <ConvertPanel 
                    config={pwaConfig} 
                    setConfig={setPwaConfig} 
                    onExport={generateAppZip} 
                    zip={zip}
                    aiAnalysis={aiAnalysis}
                    onAnalyze={smartAnalyze}
                    isLoading={isLoading}
                    onZipUpdate={(newZip) => {
                      setZip(newZip);
                      buildTree(newZip);
                    }}
                  />
                ) : selectedPath ? (
                  <FileViewer 
                    path={selectedPath} 
                    content={fileContent} 
                    onRefactor={aiRefactorFile}
                    isRefactoring={isAiRefactoring}
                  />
                ) : (
                  <div className="flex-1 flex flex-col items-center justify-center opacity-30 p-12 text-center pointer-events-none">
                    <motion.div
                      animate={{ rotate: [0, 10, -10, 0], scale: [1, 1.05, 0.95, 1] }}
                      transition={{ duration: 12, repeat: Infinity, ease: "easeInOut" }}
                    >
                      <FileArchive size={240} strokeWidth={0.25} className="text-[#141414]" />
                    </motion.div>
                    <h3 className="mt-12 font-black tracking-[-0.04em] text-5xl text-[#141414] italic">Void Storage</h3>
                    <p className="font-mono text-[11px] uppercase tracking-[0.6em] mt-4 opacity-40 italic">— Select a resource from the matrix —</p>
                  </div>
                )}
              </AnimatePresence>
            </div>
          </>
        )}
      </main>

      <style dangerouslySetInnerHTML={{ __html: `
        @keyframes loading {
          0% { width: 0; transform: translateX(0); }
          50% { width: 100%; transform: translateX(0); }
          100% { width: 0; transform: translateX(48px); }
        }
        .custom-scrollbar::-webkit-scrollbar {
          width: 4px;
        }
        .custom-scrollbar::-webkit-scrollbar-track {
          background: transparent;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb {
          background: #14141420;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb:hover {
          background: #14141440;
        }
      `}} />
    </div>
  );
}

function SecurityPanel({ issues, isScanning, onRescan }: { issues: SafetyIssue[], isScanning: boolean, onRescan: () => void }) {
  const stats = useMemo(() => {
    return {
      errors: issues.filter(i => i.type === 'error').length,
      warnings: issues.filter(i => i.type === 'warning').length,
      info: issues.filter(i => i.type === 'info').length,
    };
  }, [issues]);

  return (
    <motion.div 
      initial={{ opacity: 0, scale: 0.98 }}
      animate={{ opacity: 1, scale: 1 }}
      className="p-16 max-w-5xl mx-auto w-full pb-32 overflow-y-auto custom-scrollbar h-full"
    >
      <div className="flex items-center justify-between mb-20">
        <div>
          <h2 className="text-6xl font-black tracking-tighter mb-2 text-white">Security Loop</h2>
          <p className="text-[11px] font-black uppercase tracking-[0.4em] opacity-30 text-indigo-400 italic">Heuristic Compliance & Malware Trap</p>
        </div>
        <motion.button 
          whileHover={{ scale: 1.05, boxShadow: "0 0 30px rgba(6, 182, 212, 0.3)" }}
          whileTap={{ scale: 0.95 }}
          onClick={onRescan}
          disabled={isScanning}
          className="flex items-center gap-3 px-8 py-4 bg-cyan-600 text-white text-[11px] font-black uppercase tracking-widest rounded-2xl shadow-2xl transition-all"
        >
          {isScanning ? <Activity className="animate-spin" size={16} /> : <ShieldCheck size={16} />}
          <span>Start Sentinel Scan</span>
        </motion.button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-20">
        <div className="bg-[#0D0D0D] p-10 rounded-[40px] border border-white/5 shadow-xl relative overflow-hidden group">
          <div className="absolute top-0 left-0 w-2 h-full bg-red-500" />
          <div className="text-5xl font-black tracking-tighter mb-4 text-red-500">{stats.errors}</div>
          <div className="text-[11px] font-black uppercase tracking-[0.2em] opacity-40">Critical Faults</div>
          <ShieldAlert className="absolute -bottom-6 -right-6 opacity-[0.05] group-hover:opacity-10 transition-opacity" size={120} />
        </div>
        <div className="bg-[#0D0D0D] p-10 rounded-[40px] border border-white/5 shadow-xl relative overflow-hidden group">
          <div className="absolute top-0 left-0 w-2 h-full bg-orange-400" />
          <div className="text-5xl font-black tracking-tighter mb-4 text-orange-400">{stats.warnings}</div>
          <div className="text-[11px] font-black uppercase tracking-[0.2em] opacity-40">Heuristic Warnings</div>
          <AlertTriangle className="absolute -bottom-6 -right-6 opacity-[0.05] group-hover:opacity-10 transition-opacity" size={120} />
        </div>
        <div className="bg-[#0D0D0D] p-10 rounded-[40px] border border-white/5 shadow-xl relative overflow-hidden group">
          <div className="absolute top-0 left-0 w-2 h-full bg-cyan-400" />
          <div className="text-5xl font-black tracking-tighter mb-4 text-cyan-400">{stats.info}</div>
          <div className="text-[11px] font-black uppercase tracking-[0.2em] opacity-40">Log Entries</div>
          <div className="absolute -bottom-6 -right-6 opacity-[0.05] group-hover:opacity-10 transition-opacity">
            <Info size={120} />
          </div>
        </div>
      </div>

      <div className="space-y-6">
        <h3 className="text-[11px] font-black uppercase tracking-widest opacity-40 mb-10 border-b border-white/5 pb-4">Sentinel_Audit_Stream</h3>
        {issues.length === 0 ? (
          <div className="py-32 text-center bg-[#0D0D0D] rounded-[40px] border border-white/5 shadow-2xl">
            <motion.div
              animate={{ scale: [1, 1.1, 1], opacity: [0.3, 1, 0.3] }}
              transition={{ duration: 2, repeat: Infinity }}
            >
              <CheckCircle2 size={80} className="mx-auto text-cyan-400 mb-8" />
            </motion.div>
            <h3 className="text-2xl font-black tracking-tight text-white uppercase">System Integrity Nominal</h3>
            <p className="text-[11px] opacity-40 uppercase tracking-[0.4em] mt-4 italic">No detected hostiles in current binary layer</p>
          </div>
        ) : (
          issues.map((issue, idx) => (
            <motion.div 
              key={idx}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: idx * 0.05 }}
              className="flex items-center gap-8 p-10 bg-[#0D0D0D] rounded-[32px] border border-white/5 shadow-lg group hover:border-white/10 transition-all"
            >
              <div className="w-16 h-16 rounded-2xl bg-white/5 flex items-center justify-center shrink-0">
                {issue.type === 'error' ? <ShieldAlert className="text-red-500" size={24} /> : 
                 issue.type === 'warning' ? <AlertTriangle className="text-orange-400" size={24} /> : 
                 <Info className="text-cyan-400" size={24} />}
              </div>
              <div className="flex-1">
                <div className="flex items-center gap-4 mb-3">
                  <span className="text-[9px] font-black px-4 py-1.5 bg-white text-black rounded-full uppercase tracking-widest">{issue.file}</span>
                  <div className={`w-2 h-2 rounded-full animate-pulse ${issue.type === 'error' ? 'bg-red-500' : issue.type === 'warning' ? 'bg-orange-500' : 'bg-cyan-500'}`} />
                </div>
                <p className="text-lg font-bold text-white leading-relaxed">{issue.message}</p>
              </div>
              <ChevronRight className="opacity-10 group-hover:opacity-100 transition-opacity text-cyan-400" size={24} />
            </motion.div>
          ))
        )}
      </div>
    </motion.div>
  );
}

function ConvertPanel({ config, setConfig, onExport, zip, onZipUpdate, aiAnalysis, onAnalyze, isLoading }: { 
  config: any, 
  setConfig: (c: any) => void,
  onExport: () => void,
  zip: JSZip | null,
  onZipUpdate: (newZip: JSZip) => void,
  aiAnalysis: any,
  onAnalyze: () => void,
  isLoading: boolean
}) {
  const [fromExt, setFromExt] = useState('');
  const [toExt, setToExt] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    if (aiAnalysis && aiAnalysis.suggestions && aiAnalysis.suggestions.length > 0) {
      const matched = aiAnalysis.suggestions[0].match(/(\.\w+) to (\.\w+)/);
      if (matched) {
        setFromExt(matched[1]);
        setToExt(matched[2]);
      }
    }
  }, [aiAnalysis]);

  const handleBatchConvert = async () => {
    if (!zip || !fromExt || !toExt) return;
    setIsProcessing(true);
    setProgress(0);
    try {
      const newZip = new JSZip();
      const files = Object.entries(zip.files);
      const total = files.length;
      
      for (let i = 0; i < total; i++) {
        const [path, file] = files[i];
        if (file.dir) {
          newZip.folder(path);
          continue;
        }
        
        let newPath = path;
        const normalizedFrom = fromExt.startsWith('.') ? fromExt.toLowerCase() : `.${fromExt.toLowerCase()}`;
        if (path.toLowerCase().endsWith(normalizedFrom)) {
          const extension = fromExt.startsWith('.') ? fromExt : `.${fromExt}`;
          const targetExt = toExt.startsWith('.') ? toExt : `.${toExt}`;
          newPath = path.slice(0, -extension.length) + targetExt;
        }
        
        const content = await file.async('blob');
        newZip.file(newPath, content);
        
        if (i % 5 === 0) {
          setProgress(Math.round(((i + 1) / total) * 100));
          await new Promise(r => setTimeout(r, 10)); 
        }
      }
      setProgress(100);
      onZipUpdate(newZip);
    } catch (err) {
      console.error("Batch conversion error:", err);
    } finally {
      setIsProcessing(false);
      setTimeout(() => setProgress(0), 1000);
    }
  };

  return (
    <motion.div 
      initial={{ opacity: 0, scale: 0.98 }}
      animate={{ opacity: 1, scale: 1 }}
      className="p-10 lg:p-20 max-w-[1400px] mx-auto w-full pb-32 overflow-y-auto custom-scrollbar h-full"
    >
      <div className="grid grid-cols-12 gap-16">
        {/* Left Column: AI & Forge Controls */}
        <div className="col-span-12 lg:col-span-7 space-y-16">
          <div className="flex flex-col gap-6">
            <div className="flex items-center gap-4">
              <div className="px-4 py-1.5 bg-indigo-600 text-white text-[9px] font-black uppercase tracking-[0.3em] rounded-full">Neural Engine v3</div>
              <div className="h-px flex-1 bg-white/5" />
            </div>
            <div className="flex items-end justify-between">
              <div>
                <h2 className="text-7xl font-black tracking-[-0.04em] leading-none mb-4 lowercase text-white">Project.<span className="text-indigo-500">Forge</span></h2>
                <p className="text-[10px] font-black uppercase tracking-[0.4em] opacity-30 text-indigo-400 italic">Neural Project Recombination Strategy</p>
              </div>
              <motion.button 
                whileHover={{ scale: 1.05, boxShadow: "0 0 30px rgba(99, 102, 241, 0.4)" }}
                whileTap={{ scale: 0.95 }}
                onClick={onAnalyze}
                disabled={isLoading}
                className="flex items-center gap-4 px-10 py-5 bg-[#0D0D0D] text-white text-[11px] font-black uppercase tracking-[0.2em] rounded-3xl border border-white/10 shadow-2xl hover:bg-[#141414] disabled:opacity-20 transition-all"
              >
                {isLoading ? <Activity className="animate-spin" size={16} /> : <Zap size={16} className="text-indigo-400" />}
                <span>Synchronize AI Core</span>
              </motion.button>
            </div>
          </div>

          <AnimatePresence mode="wait">
            {aiAnalysis ? (
              <motion.div 
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                className="bg-[#0D0D0D] p-12 rounded-[52px] border border-white/5 shadow-[0_40px_100px_rgba(0,0,0,0.4)] relative overflow-hidden group"
              >
                <div className="absolute top-0 right-0 w-32 h-32 bg-indigo-500/5 blur-[80px] -translate-y-1/2 translate-x-1/2 group-hover:bg-indigo-500/10 transition-colors" />
                <div className="relative z-10 text-white">
                  <div className="flex items-center gap-6 mb-12">
                    <div className="w-16 h-16 bg-indigo-600 rounded-3xl flex items-center justify-center shadow-2xl shadow-indigo-500/20">
                      <BrainCircuit className="text-white" size={32} />
                    </div>
                    <div>
                      <h3 className="text-[10px] font-black uppercase tracking-[0.3em] opacity-30 mb-1 italic text-indigo-400">Class_Identification</h3>
                      <p className="text-3xl font-black tracking-tight uppercase">{aiAnalysis.projectType}</p>
                    </div>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                    {aiAnalysis.suggestions.map((s: string, i: number) => (
                      <motion.div 
                        key={i} 
                        initial={{ opacity: 0, x: -10 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: i * 0.1 }}
                        className="group p-8 bg-white/5 rounded-[32px] border border-white/5 hover:border-indigo-500/30 hover:bg-indigo-500/5 transition-all shadow-sm"
                      >
                        <Zap size={20} className="text-indigo-400 mb-6" />
                        <p className="text-[11px] font-black leading-relaxed opacity-60 uppercase tracking-widest leading-loose">{s}</p>
                      </motion.div>
                    ))}
                  </div>
                </div>
              </motion.div>
            ) : (
              <motion.div 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="py-32 text-center border-4 border-dashed border-white/5 rounded-[52px] opacity-30 grayscale hover:grayscale-0 transition-all cursor-wait"
              >
                <BrainCircuit size={64} className="mx-auto mb-8 text-indigo-400" />
                <p className="text-[11px] font-black uppercase tracking-[0.6em] animate-pulse">Waiting for Neural Sync...</p>
              </motion.div>
            )}
          </AnimatePresence>

          <div className="bg-[#0D0D0D] text-white p-12 rounded-[52px] shadow-2xl relative overflow-hidden group border border-white/5">
            <div className="absolute top-0 right-0 p-12 opacity-[0.03] pointer-events-none group-hover:opacity-5 transition-opacity">
              <Zap size={240} strokeWidth={1} />
            </div>
            <div className="relative z-10 w-full">
              <div className="flex items-center justify-between mb-12">
                <h3 className="text-[11px] font-black uppercase tracking-[0.4em] text-cyan-400 italic">Binary Recombination Layer</h3>
                <div className="flex gap-1.5">
                  <div className="w-1.5 h-1.5 rounded-full bg-cyan-500 animate-pulse" />
                </div>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-12 mb-12">
                <div className="space-y-4">
                  <label className="text-[9px] font-black uppercase tracking-[0.3em] opacity-40">Entry_Point_Ext</label>
                  <input 
                    type="text" 
                    placeholder=".txt"
                    className="w-full bg-white/5 border-b-2 border-white/10 py-5 px-6 rounded-2xl text-2xl font-black focus:border-indigo-500 outline-none transition-all placeholder:opacity-5 text-white"
                    value={fromExt}
                    onChange={(e) => setFromExt(e.target.value)}
                  />
                </div>
                <div className="space-y-4">
                  <label className="text-[9px] font-black uppercase tracking-[0.3em] opacity-40">Exit_Point_Ext</label>
                  <input 
                    type="text" 
                    placeholder=".html"
                    className="w-full bg-white/5 border-b-2 border-white/10 py-5 px-6 rounded-2xl text-2xl font-black focus:border-indigo-500 outline-none transition-all placeholder:opacity-5 text-white"
                    value={toExt}
                    onChange={(e) => setToExt(e.target.value)}
                  />
                </div>
              </div>

              <div className="relative">
                <motion.button 
                  whileHover={{ scale: 1.02, y: -2, boxShadow: "0 0 40px rgba(6, 182, 212, 0.4)" }}
                  whileTap={{ scale: 0.98 }}
                  onClick={handleBatchConvert}
                  disabled={isProcessing || !fromExt || !toExt}
                  className="w-full py-7 bg-cyan-600 text-white text-[11px] font-black uppercase tracking-[0.5em] rounded-3xl shadow-2xl disabled:opacity-10 transition-all relative z-10"
                >
                  {isProcessing ? "Processing Binary Stream..." : "Inject Transformation Sequence"}
                </motion.button>
                {isProcessing && (
                  <div className="absolute -bottom-4 left-0 w-full h-1 bg-white/5 rounded-full overflow-hidden z-20">
                    <motion.div 
                      initial={{ width: 0 }}
                      animate={{ width: `${progress}%` }}
                      className="h-full bg-cyan-400 shadow-[0_0_20px_#22d3ee]"
                    />
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* Right Column: Branding & Export */}
        <div className="col-span-12 lg:col-span-5 space-y-12">
          <div className="bg-[#0D0D0D] p-12 rounded-[52px] border border-white/5 shadow-2xl">
            <h3 className="text-[11px] font-black uppercase tracking-[0.3em] opacity-30 mb-12 border-b border-white/5 pb-6 flex items-center justify-between text-indigo-400 italic">
              <span>Node_Metadata</span>
              <Settings size={14} className="opacity-40" />
            </h3>
            <div className="space-y-10">
              <div className="space-y-4">
                <label className="text-[10px] font-black uppercase tracking-widest opacity-30 px-2">Binary Identity</label>
                <input 
                  type="text" 
                  className="w-full bg-white/5 px-8 py-5 rounded-[24px] text-base font-black outline-none focus:ring-4 ring-indigo-500/10 transition-all text-white border border-white/5"
                  value={config.name}
                  onChange={(e) => setConfig({...config, name: e.target.value})}
                  placeholder="Module Identity"
                />
              </div>
              <div className="grid grid-cols-2 gap-8">
                 <div className="space-y-4">
                    <label className="text-[10px] font-black uppercase tracking-widest opacity-30 px-2">Flux_Tint</label>
                    <div className="relative group p-1 bg-white/5 rounded-[24px] border border-white/5">
                      <input 
                        type="color" 
                        className="w-full h-16 cursor-pointer rounded-[20px] border-none outline-none shadow-inner bg-transparent"
                        value={config.themeColor}
                        onChange={(e) => setConfig({...config, themeColor: e.target.value})}
                      />
                    </div>
                 </div>
                 <div className="space-y-4">
                    <label className="text-[10px] font-black uppercase tracking-widest opacity-30 px-2">Core_Base</label>
                    <div className="relative group p-1 bg-white/5 rounded-[24px] border border-white/5">
                      <input 
                        type="color" 
                        className="w-full h-16 cursor-pointer rounded-[20px] border-none outline-none shadow-inner bg-transparent"
                        value={config.backgroundColor}
                        onChange={(e) => setConfig({...config, backgroundColor: e.target.value})}
                      />
                    </div>
                 </div>
              </div>
            </div>
          </div>

          <div className="p-12 rounded-[52px] bg-[#050505] border-4 border-white/20 relative shadow-2xl group overflow-hidden">
            <div className="absolute -inset-10 bg-indigo-600/5 blur-[100px] opacity-0 group-hover:opacity-100 transition-opacity" />
            <div className="flex flex-col items-center text-center relative z-10">
              <div className="w-24 h-24 bg-white rounded-[32px] mb-10 flex items-center justify-center shadow-[0_0_50px_rgba(255,255,255,0.1)] relative overflow-hidden group cursor-cell">
                <motion.div 
                  animate={{ scale: [1, 1.2, 1] }} 
                  transition={{ duration: 4, repeat: Infinity }}
                  className="text-[#050505] font-black text-2xl font-mono"
                >
                  {config.shortName?.slice(0, 2).toUpperCase() || 'ZA'}
                </motion.div>
                <div className="absolute inset-x-0 bottom-0 h-1 bg-indigo-500" />
              </div>
              
              <h4 className="text-4xl font-black tracking-[-0.03em] mb-3 line-clamp-1 italic text-white uppercase">{config.name || 'UNLISTED CORE'}</h4>
              <p className="text-[9px] font-black opacity-20 uppercase tracking-[0.8em] mb-12 text-indigo-400">Binary Protocol 10.4.2 — SECURE</p>

              <div className="w-full space-y-6 mb-12 px-4 shadow-inner">
                 <div className="flex justify-between items-center text-[10px] font-black border-b border-white/5 pb-5">
                    <span className="opacity-20 uppercase tracking-widest font-mono">CRC_CHECK</span>
                    <div className="flex items-center gap-2 text-cyan-400">
                      <div className="w-1.5 h-1.5 rounded-full bg-cyan-400 shadow-[0_0_10px_#22d3ee]" />
                      <span className="uppercase tracking-[0.2em] italic">Validated</span>
                    </div>
                 </div>
                 <div className="flex justify-between items-center text-[10px] font-black border-b border-white/5 pb-5">
                    <span className="opacity-20 uppercase tracking-widest font-mono">TARGET_PLATE</span>
                    <span className="uppercase tracking-[0.2em] text-white">NEURAL PWA</span>
                 </div>
              </div>

              <motion.button 
                whileHover={{ scale: 1.05, boxShadow: "0 0 60px rgba(255,255,255,0.15)" }}
                whileTap={{ scale: 0.95 }}
                onClick={onExport}
                className="w-full py-7 bg-white text-[#050505] text-[11px] font-black uppercase tracking-[0.6em] rounded-[32px] shadow-2xl flex items-center justify-center gap-4 group"
              >
                <Download size={20} className="group-hover:translate-y-1 transition-transform" />
                <span>Compile & Export</span>
              </motion.button>
            </div>
          </div>
        </div>
      </div>
    </motion.div>
  );
}

interface TreeProps {
  node: TreeNode;
  onSelect: (p: string, e: FileEntry) => void;
  selectedPath: string | null;
  level: number;
}

const TreeComponent: React.FC<TreeProps> = ({ node, onSelect, selectedPath, level }) => {
  const [isOpen, setIsOpen] = useState(level === 0);
  const isSelected = selectedPath === node.path;

  const childrenKeys = Object.keys(node.children).sort((a, b) => {
    const aIsDir = node.children[a].isDir;
    const bIsDir = node.children[b].isDir;
    if (aIsDir && !bIsDir) return -1;
    if (!aIsDir && bIsDir) return 1;
    return a.localeCompare(b);
  });

  if (node.name === 'root') {
    return (
      <div className="space-y-1">
        {childrenKeys.map(key => (
          <TreeComponent key={key} node={node.children[key]} onSelect={onSelect} selectedPath={selectedPath} level={level + 1} />
        ))}
      </div>
    );
  }

  const handleClick = () => {
    if (node.isDir) {
      setIsOpen(!isOpen);
    } else if (node.entry) {
      onSelect(node.path, node.entry);
    }
  };

  return (
    <div className="select-none">
      <div 
        onClick={handleClick}
        className={`group flex items-center gap-2 px-3 py-2 rounded-xl cursor-pointer transition-all ${
          isSelected ? 'bg-indigo-600 text-white shadow-[0_0_20px_rgba(99,102,241,0.3)]' : 'text-white/40 hover:bg-white/5 hover:text-white'
        }`}
      >
        <span className="flex-shrink-0">
          {node.isDir ? (
            isOpen ? <ChevronDown size={14} strokeWidth={3} /> : <ChevronRight size={14} strokeWidth={3} />
          ) : (
            <FileIcon size={14} strokeWidth={2} className={isSelected ? 'text-white' : 'text-indigo-400 opacity-60'} />
          )}
        </span>
        {node.isDir ? <Folder size={14} className={`flex-shrink-0 ${isSelected ? 'text-white' : 'text-indigo-400 opacity-40'} fill-current`} /> : null}
        <span className={`text-[11px] truncate tracking-tight font-black uppercase ${isSelected ? 'opacity-100' : 'opacity-80'}`}>
          {node.name}
        </span>
      </div>
      
      {node.isDir && isOpen && (
        <div className="ml-4 border-l border-white/5 pl-2 mt-1 space-y-1">
          {childrenKeys.map(key => (
            <TreeComponent key={key} node={node.children[key]} onSelect={onSelect} selectedPath={selectedPath} level={level + 1} />
          ))}
        </div>
      )}
    </div>
  );
}

function FileViewer({ path, content, onRefactor, isRefactoring }: { 
  path: string, 
  content: string | null, 
  onRefactor: (target: string) => void,
  isRefactoring: boolean
}) {
  const codeRef = useRef<HTMLElement>(null);
  const [showRefactorOptions, setShowRefactorOptions] = useState(false);
  const extension = path.split('.').pop()?.toLowerCase() || '';
  const isImage = ['png', 'jpg', 'jpeg', 'gif', 'svg', 'webp'].includes(extension);
  const isVideo = ['mp4', 'webm', 'ogg'].includes(extension);
  const isAudio = ['mp3', 'wav', 'ogg'].includes(extension);
  const isMd = extension === 'md';
  const isPdf = extension === 'pdf';
  const isCode = !isImage && !isVideo && !isAudio && !isMd && !isPdf;

  useEffect(() => {
    if (codeRef.current && content && isCode) {
      Prism.highlightElement(codeRef.current);
    }
  }, [content, path, isCode]);

  const getFileIcon = () => {
    if (isImage) return <FileImage size={18} />;
    if (isVideo) return <FileVideo size={18} />;
    if (isAudio) return <FileAudio size={18} />;
    if (isMd || isPdf) return <FileText size={18} />;
    return <FileCode size={18} />;
  };

  return (
    <div className="flex-1 flex flex-col overflow-hidden bg-[#050505] relative shadow-2xl">
      <div className="absolute inset-0 hardware-grid opacity-[0.03] pointer-events-none" />
      <div className="h-24 border-b border-white/5 px-12 flex items-center justify-between bg-[#0D0D0D]/50 backdrop-blur-xl z-10 sticky top-0">
        <div className="flex items-center gap-6">
          <div className="flex items-center gap-2 p-4 bg-white/5 rounded-2xl text-indigo-400 border border-white/5">
            {getFileIcon()}
          </div>
          <div className="flex flex-col">
            <span className="text-[12px] font-black tracking-widest text-white truncate max-w-xl uppercase">{path.split('/').pop()}</span>
            <span className="text-[9px] font-mono opacity-20 lowercase tracking-widest mt-1">/bin/{path}</span>
          </div>
        </div>
        <div className="flex items-center gap-10">
          {isCode && (
            <div className="relative">
              <motion.button 
                whileHover={{ scale: 1.05, boxShadow: "0 0 30px rgba(99, 102, 241, 0.4)" }}
                whileTap={{ scale: 0.95 }}
                onClick={() => setShowRefactorOptions(!showRefactorOptions)}
                className="flex items-center gap-3 px-6 py-3.5 bg-indigo-600 text-white text-[10px] font-black uppercase tracking-[0.2em] rounded-2xl shadow-2xl"
              >
                {isRefactoring ? <Activity className="animate-spin" size={16} /> : <Wand2 size={16} />}
                <span>Neural Refactor</span>
              </motion.button>
              
              <AnimatePresence>
                {showRefactorOptions && (
                  <motion.div 
                    initial={{ opacity: 0, y: 10, scale: 0.9 }}
                    animate={{ opacity: 1, y: 0, scale: 1 }}
                    exit={{ opacity: 0, y: 10, scale: 0.9 }}
                    className="absolute right-0 top-full mt-4 w-56 bg-[#0D0D0D] border border-white/10 rounded-3xl shadow-[0_20px_50px_rgba(0,0,0,0.8)] p-2 z-50 origin-top-right overflow-hidden"
                  >
                     {['TypeScript', 'Tailwind', 'Modernize', 'Optimize'].map(opt => (
                       <button 
                        key={opt}
                        onClick={() => {
                          onRefactor(opt);
                          setShowRefactorOptions(false);
                        }}
                        className="w-full text-left px-5 py-4 text-[10px] font-black uppercase tracking-widest hover:bg-white hover:text-black rounded-2xl transition-all flex items-center justify-between group"
                       >
                         <span>{opt}</span>
                         <Zap size={12} className="opacity-0 group-hover:opacity-100 transition-opacity" />
                       </button>
                     ))}
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          )}
          <div className="px-6 py-3 bg-white/5 rounded-2xl border border-white/5 flex items-center gap-4 text-[10px] font-black uppercase tracking-widest opacity-40">
            <div className="w-1.5 h-1.5 rounded-full bg-indigo-500 shadow-[0_0_10px_#6366f1]" />
            <span>.{extension}</span>
          </div>
        </div>
      </div>
      
      <div className="flex-1 overflow-auto p-0 relative custom-scrollbar bg-[#050505]">
        {isImage ? (
          <div className="w-full h-full flex flex-col items-center justify-center p-32">
            <motion.div 
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              className="relative p-6 bg-white/5 border border-white/10 rounded-[64px] shadow-2xl backdrop-blur-2xl"
            >
              <img 
                src={content || ''} 
                alt={path} 
                className="max-w-full max-h-[50vh] rounded-[48px] block shadow-[0_0_50px_rgba(0,0,0,0.5)]"
                referrerPolicy="no-referrer"
              />
            </motion.div>
          </div>
        ) : isVideo ? (
          <div className="w-full h-full flex flex-col items-center justify-center p-20">
            <video controls className="max-w-full max-h-full rounded-3xl shadow-2xl border-4 border-white/10 overflow-hidden">
              <source src={content || ''} type={`video/${extension}`} />
            </video>
          </div>
        ) : isAudio ? (
          <div className="w-full h-full flex flex-col items-center justify-center p-32">
            <div className="w-full max-w-2xl bg-[#0D0D0D] p-16 rounded-[64px] border border-white/10 shadow-2xl flex flex-col items-center gap-12 relative overflow-hidden">
               <div className="absolute -bottom-20 -right-20 opacity-5 text-indigo-500 scale-150">
                  <FileAudio size={200} />
               </div>
               <div className="w-24 h-24 bg-indigo-600/10 rounded-full flex items-center justify-center text-indigo-400 shadow-[0_0_30px_rgba(99,102,241,0.2)]">
                  <FileAudio size={40} />
               </div>
               <audio controls className="w-full dark-audio-player">
                <source src={content || ''} type={`audio/${extension}`} />
              </audio>
            </div>
          </div>
        ) : isPdf ? (
          <iframe src={content || ''} className="w-full h-full grayscale invert border-none" title={path} />
        ) : isMd ? (
          <div className="p-24 max-w-5xl mx-auto prose prose-invert prose-zinc prose-lg">
            <Markdown>{content || ''}</Markdown>
          </div>
        ) : (
          <div className="relative">
            <div className="absolute top-0 left-0 w-12 h-full bg-white/[0.02] border-r border-white/5 pointer-events-none" />
            <pre className="!bg-transparent !p-12 !pl-20 !m-0 !text-sm leading-relaxed font-mono text-[#E4E3E0]">
              <code ref={codeRef} className={`language-${getLanguageMap(extension)}`}>
                {content}
              </code>
            </pre>
          </div>
        )}
      </div>
    </div>
  );
}

function getLanguageMap(ext: string) {
  const maps: { [key: string]: string } = {
    'js': 'javascript',
    'jsx': 'javascript',
    'ts': 'typescript',
    'tsx': 'typescript',
    'html': 'markup',
    'css': 'css',
    'json': 'json',
    'md': 'markdown'
  };
  return maps[ext] || 'clike';
}
